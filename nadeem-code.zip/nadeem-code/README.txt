API Rate Limiter

Introduction
- There are 5 classes (WebService, RequestListener, MethodSpec, ApiService and RateLimiter), out of which
  RateLimiter is the main class. The algorithm implemented is called 'Sliding Window Approach with FIFO Queue'
  which mantains a bounded queue to store timestamps of accepted request and it will remove stored
  timestamps based on granularity for incoming requests, Please check the code implemented, it has comments which explains logic.


 How to Test?
 - Run the main class (RateLimiter.java) and please ensure to change the filePath in the class to the 
   location where the file 'api_rate_limiter.json' is stored. When you run the main, following inputs
   should be given

   Enter name of the service you want to test:-  (enter 'pixelService')
   Enter name of the api:-  (enter 'createPixel')
   Enter name of the method:- (enter 'GET')

   // now you will be prompted to enter either 'y' or 'quit' for hitting the request, please do so

   Enter 'Y/y' to send request, or enter 'quit' to exit:-   (enter 'y' to hit or enter 'quit' to exit)

   // Sample Output
   -----------------------------------------------------------------------------------------
        Enter name of the service you want to test:- pixelService
        Enter name of the api:- createPixel
        Enter name of the method:- GET
        Enter 'Y/y' to send request, or enter 'quit' to exit:- y

        2019-12-26 17:45:52.084

        Accepted Requests: 1

        Enter 'Y/y' to send request, or enter 'quit' to exit:- y

        2019-12-26 17:45:52.084
        2019-12-26 17:45:52.542

        Accepted Requests: 2

        Enter 'Y/y' to send request, or enter 'quit' to exit:- y

        2019-12-26 17:45:52.084
        2019-12-26 17:45:52.542
        2019-12-26 17:45:54.12

        Accepted Requests: 3

        Enter 'Y/y' to send request, or enter 'quit' to exit:- y

        2019-12-26 17:45:52.084
        2019-12-26 17:45:52.542
        2019-12-26 17:45:54.12
        2019-12-26 17:45:54.987

        Accepted Requests: 4

        Enter 'Y/y' to send request, or enter 'quit' to exit:- 

      -----------------------------------------------------------------------------------------


Questions
- For any questions/doubts, please call me to '9538491876' or mail me 'naddybot@gmail.com'
