package com.lifesight.tech;

import java.sql.Timestamp;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

public class RequestListener implements Runnable {

	private final WebService service;
	private volatile boolean isDone;
	private Queue<Timestamp> queue;
	private MethodSpec globalSpec;
	private MethodSpec apiSpec;

	public RequestListener(final WebService service, final String apiName, final String methodType) {
		this.service = service;
		this.queue = new LinkedList<>();

		setGlobalSpec(methodType);
		setApiSpec(apiName, methodType);
	}

	private void setGlobalSpec(final String methodType) {
		this.service.getGlobalLimits().forEach(globalSpec -> {
			if (globalSpec.getMethodType().equals(methodType)) {
				this.globalSpec = globalSpec;
			}
		});

	}

	private void setApiSpec(final String apiName, final String methodType) {
		this.service.getApiLimits().forEach(apiService -> {
			if (apiService.getApiName().equals(apiName)) {
				List<MethodSpec> list = apiService.getMethods().stream()
						.filter(spec -> spec.getMethodType().equals(methodType)).collect(Collectors.toList());

				if (list != null && list.get(0) != null)
					this.apiSpec = list.get(0);
			}
		});

	}

	// Checks if api limit threshold time is exceeded
	private boolean hasApiLimitExpired(Timestamp previous, Timestamp current) {
		if (this.apiSpec == null)
			return false;

		long diff = current.getTime() - previous.getTime();
		long inSeconds = diff / 1000;

		TimeUnit granularity = this.apiSpec.getGranularity();
		if (granularity == TimeUnit.SECONDS && inSeconds >= 0) {
			return true;
		} else if (granularity == TimeUnit.MINUTES && inSeconds >= 60) {
			return true;
		} else if (granularity == TimeUnit.HOURS && inSeconds >= 3600) {
			return true;
		} else {
			return false;
		}
	}

	private int acceptIncomingRequest(int requestCount, Timestamp currentRequest, int limit) {
		if (queue.size() == limit) {
			queue.remove();
		}

		queue.add(currentRequest);

		System.out.println("Request Accepted!!");

		return ++requestCount;
	}

	@Override
	public void run() {
		int requestAccepted = 0;
		Timestamp resetTracker = null;

		/**
		 * Sliding Window Approach with FIFO Queue
		 * 
		 * This algorithm works by maintaining a bounded queue which stores timestamp's
		 * of accepted requests and based on granularity it either accepts the request
		 * or rejects it.
		 * 
		 */
		while (!isDone) {
			Scanner sc = new Scanner(System.in);
			System.out.print("Enter 'Y/y' to send request, or enter 'quit' to exit:- ");
			String input = sc.nextLine();

			if (input.trim().toLowerCase().equals("y")) {
				Timestamp currentRequest = new Timestamp(System.currentTimeMillis());

				if (resetTracker != null && hasApiLimitExpired(resetTracker, currentRequest)) {
					// if the time has elapsed, reset the count
					requestAccepted = 0;

					int offset;
					TimeUnit granularity = this.apiSpec.getGranularity();
					if (granularity == TimeUnit.SECONDS) {
						offset = 0;
					} else if (granularity == TimeUnit.MINUTES) {
						offset = 60;
					} else {
						offset = 3600;
					}

					// keep removing timestamp elements which is no longer considered
					// for comparison based on granularity of API Limit
					while (queue.peek() != null
							&& (((currentRequest.getTime() - queue.peek().getTime()) / 1000) >= offset))
						queue.remove();

					// consider current request as base to start
					// tracking the future requests
					resetTracker = currentRequest;

				} else if (requestAccepted == this.apiSpec.getRequestLimit()) {

					System.out.println("Requested Rejected, api limit reached!");

					continue;
				}

				if (this.globalSpec != null) {

					int globalLimit = this.globalSpec.getRequestLimit();
					TimeUnit granularity = this.globalSpec.getGranularity();

					// if the queue is empty, then this is the first
					// request which we should accept and assign the
					// api @resetTracker as the base point to start
					// tracking the requests going forward
					if (queue.peek() == null) {

						queue.add(currentRequest);
						resetTracker = currentRequest;
						requestAccepted++;

					} else if (queue.size() < globalLimit) {

						// if the window of accepted request is less then blindly add
						// to the queue window
						queue.add(currentRequest);
						requestAccepted++;

					} else {

						// if the queue is full (queue.size == globalLimit)
						// then before accepting the request, compare if
						// the granularity has elapsed or not with FIFO element, if so
						// dequeue the FIFO element and add this element
						Timestamp lastAcceptedRequest = queue.peek();
						long diff = currentRequest.getTime() - lastAcceptedRequest.getTime();

						long inSeconds = diff / 1000;

						if (granularity == TimeUnit.SECONDS) {
							if (inSeconds >= 0) {
								requestAccepted = acceptIncomingRequest(requestAccepted, currentRequest, globalLimit);
							} else {
								System.out.println("******************************************");
								System.out.println("Request is Rejected - " + currentRequest.toString());
							}
						} else if (granularity == TimeUnit.MINUTES) {
							if (inSeconds >= 60) {
								requestAccepted = acceptIncomingRequest(requestAccepted, currentRequest, globalLimit);
							} else {
								System.out.println("Request is Rejected - " + currentRequest.toString());
							}
						} else if (granularity == TimeUnit.HOURS) {
							if (inSeconds >= 3600) {
								requestAccepted = acceptIncomingRequest(requestAccepted, currentRequest, globalLimit);
							} else {
								System.out.println("Request is Rejected - " + currentRequest.toString());
							}
						}
					}
				}
			} else if (input.trim().toLowerCase().equals("quit")) {
				// exit the while loop
				isDone = true;
			}

			System.out.println();
			queue.forEach(element -> System.out.println(element.toString()));
			System.out.println();
			System.out.println("Accepted Requests: " + requestAccepted);
			System.out.println();
		}

	}

}
