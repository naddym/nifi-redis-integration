package com.lifesight.tech;

import java.util.concurrent.TimeUnit;

public class MethodSpec {
	
	private String methodType;
	private int requestLimit;
	private TimeUnit granularity;
	
	public MethodSpec(final String type, final int limit, final String granularity) {
		this.methodType = type;
		this.requestLimit = limit;
		this.granularity = getTimeUnit(granularity);
	}
	
	public String getMethodType() {
		return methodType;
	}

	public void setMethodType(String methodType) {
		this.methodType = methodType;
	}

	public int getRequestLimit() {
		return requestLimit;
	}

	public void setRequestLimit(int requestLimit) {
		this.requestLimit = requestLimit;
	}

	public TimeUnit getGranularity() {
		return granularity;
	}

	public void setGranularity(TimeUnit granularity) {
		this.granularity = granularity;
	}
	
	private TimeUnit getTimeUnit(String unit) {
		switch (unit.toLowerCase()) {
		case "seconds":
			return TimeUnit.SECONDS;
		case "minute":
			return TimeUnit.MINUTES;
		case "hour":
			return TimeUnit.HOURS;
		default:
			return null;
		}
	}
}
