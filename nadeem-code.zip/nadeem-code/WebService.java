package com.lifesight.tech;

import java.util.ArrayList;
import java.util.List;

public class WebService {

	private String serviceName;
	private String hostName;
	private int port;
	private List<MethodSpec> globalLimits;
	private List<ApiService> apiLimits;
	
	public WebService(final String name, final String host, final int port) {
		this.serviceName = name;
		this.hostName = host;
		this.port = port;
		this.globalLimits = new ArrayList<>();
		this.apiLimits = new ArrayList<>();
	}
	
	public List<MethodSpec> getGlobalLimits() {
		return globalLimits;
	}

	public void addGlobalLimit(MethodSpec globalLimit) {
		this.globalLimits.add(globalLimit);
	}
	
	public void setGlobalLimits(List<MethodSpec> globalLimits) {
		this.globalLimits = globalLimits;
	}

	public void addApiLimit(ApiService apiService) {
		this.apiLimits.add(apiService);
	}
	
	public List<ApiService> getApiLimits() {
		return apiLimits;
	}

	public void setApiLimits(List<ApiService> apiLimits) {
		this.apiLimits = apiLimits;
	}

	public String getServiceName() {
		return serviceName;
	}

	public String getHostName() {
		return hostName;
	}
	
	public int getPort() {
		return port;
	}
}
