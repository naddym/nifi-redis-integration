package com.lifesight.tech;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/**
 * 
 * @author Mohammed Nadeem
 * @phone 9539481987
 * @email naddybot@gmail.com, nadeemm410@gmail.com
 *
 */
public class RateLimiter {

	private static List<String> methodTypes = Arrays.asList("GET", "POST","UPDATE","DELETE");
	private static List<WebService> webServices = new ArrayList<>();
	
	private static WebService initService(JSONObject service) {

		String serviceName = (String) service.get("service");
		String host = (String) service.get("host");
		int port = Integer.parseInt((String) service.get("port"));

		JSONObject globalLimits = (JSONObject) service.get("globalLimits");
		JSONArray apiLimits = (JSONArray) service.get("apiLimits");

		WebService webService = new WebService(serviceName, host, port);

		methodTypes.forEach(method -> {
			JSONObject obj = (JSONObject) globalLimits.get(method);
			if (obj != null) {
				webService.addGlobalLimit(new MethodSpec(method, Integer.parseInt((String) obj.get("limit")),
						(String) obj.get("granularity")));
			}
		});

		for (int i = 0; i < apiLimits.size(); i++) {
			JSONObject obj = (JSONObject) apiLimits.get(i);

			final String apiName = (String) obj.get("api");
			ApiService apiService = new ApiService(apiName);

			JSONObject methodObj = (JSONObject) obj.get("methods");

			methodTypes.forEach(method -> {
				JSONObject apiMethodObj = (JSONObject) methodObj.get(method);
				if (apiMethodObj != null) {
					apiService.addMethod(new MethodSpec(method, Integer.parseInt((String) apiMethodObj.get("limit")),
							(String) apiMethodObj .get("granularity")));
				}
			});

			webService.addApiLimit(apiService);
		}
		
		return webService;
	}

	public static void main(String[] args) throws IOException {
		// json parser
		JSONParser jsonParser = new JSONParser();
		// thread-pool service
		ExecutorService executorService = Executors.newSingleThreadExecutor();
		FileReader reader = null;

		final String filePath = "src/api_rate_limiter.json";
		try {
			reader = new FileReader(filePath);
			
			JSONArray services = (JSONArray) jsonParser.parse(reader);;
			services.forEach(service -> 
				webServices.add(initService((JSONObject)service))
			);
			
			Scanner sc = new Scanner(System.in);
			System.out.print("Enter name of the service you want to test:- ");
			String serviceName = sc.nextLine();
			System.out.print("Enter name of the api:- ");
			String apiName = sc.nextLine();
			System.out.print("Enter name of the method:- ");
			String methodType = sc.nextLine();
			
			webServices.forEach(webService -> {
				if (webService.getServiceName().equals(serviceName.trim())) {
					executorService.submit(new RequestListener(webService, apiName, methodType.toUpperCase()));
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			if (reader != null) {
				reader.close();
			}
			// shutdown single threaded pool
			executorService.shutdown();
		}

	}

}
